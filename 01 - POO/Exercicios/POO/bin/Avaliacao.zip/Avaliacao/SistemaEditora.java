package Avaliacao;

public interface SistemaEditora {
	// Explicação do projeto na classe main
	public void cadastrarEditora();
	public void listarEditora();
	public void alterarEditora();
	public void removerEditora();
}
