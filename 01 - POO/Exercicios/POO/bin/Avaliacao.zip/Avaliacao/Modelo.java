package Avaliacao;

public class Modelo {
	// Explicação do projeto na classe main
	//método que será implementado nas classes que extendem Modelo (Comic e Editora)
	public String emTexto() {
		return this.toString();
	}
}
