package Avaliacao;

public interface SistemaComics {
	// Explicação do projeto na classe main
	public void cadastrarComic();
	public void listarComic();
	public void alterarComic();
	public void removerComic();

}
